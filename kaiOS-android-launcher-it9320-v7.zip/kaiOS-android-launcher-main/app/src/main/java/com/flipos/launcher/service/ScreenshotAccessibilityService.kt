package com.flipos.launcher.service

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.ViewConfiguration
import android.view.accessibility.AccessibilityEvent

/**
 * Key helper for the it9320, enabled once by the user in Settings > Accessibility.
 *
 * Accessibility services see hardware keys *before* the system's own key handling, which is
 * the only way a launcher can:
 *  - take a screenshot when * and # are pressed together, on any screen
 *    (GLOBAL_ACTION_TAKE_SCREENSHOT, Android 9+), and
 *  - claim keys the firmware would otherwise act on itself while Home is on screen:
 *    a long press of # (the firmware takes a screenshot) and the call key (nothing happens).
 *
 * While Home is shown, MainActivity registers [homeKeyHandler]; this service then swallows
 * # and the call key and reports them to Home instead. Everywhere else keys pass through
 * untouched, except that * and # are swallowed while the screenshot combo is held.
 */
class ScreenshotAccessibilityService : AccessibilityService() {

    enum class HomeKey { POUND_SHORT, POUND_LONG, CALL, OTHER }

    private val mainHandler = Handler(Looper.getMainLooper())

    private var starDown = false
    private var poundDown = false
    private var comboActive = false

    /** True while a # press was swallowed by [handlePound], so its release must be swallowed too. */
    private var poundConsumed = false
    private var poundLongFired = false

    private val poundLongTask = Runnable {
        if (poundConsumed && !comboActive) {
            poundLongFired = true
            homeKeyHandler?.invoke(HomeKey.POUND_LONG, KeyEvent.KEYCODE_POUND)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        mainHandler.removeCallbacks(poundLongTask)
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val down = event.action == KeyEvent.ACTION_DOWN
        val repeat = down && event.repeatCount > 0
        val handler = homeKeyHandler

        return when (code) {
            KeyEvent.KEYCODE_STAR, KeyEvent.KEYCODE_POUND -> handleStarPound(code, down, repeat)
            KeyEvent.KEYCODE_CALL -> {
                if (handler == null) return false
                if (down && !repeat) handler(HomeKey.CALL, code)
                true
            }
            else -> {
                // Lets Home report keys it does not know (diagnostics); never swallowed.
                if (handler != null && down && !repeat) handler(HomeKey.OTHER, code)
                false
            }
        }
    }

    private fun handleStarPound(code: Int, down: Boolean, repeat: Boolean): Boolean {
        if (!repeat) {
            if (code == KeyEvent.KEYCODE_STAR) starDown = down else poundDown = down
        }
        if (down && !repeat && starDown && poundDown && !comboActive) {
            comboActive = true
            lastComboAt = SystemClock.uptimeMillis()
            mainHandler.removeCallbacks(poundLongTask)
            takeScreenshot()
        }

        var consume = comboActive
        if (code == KeyEvent.KEYCODE_POUND) {
            if (comboActive) {
                if (!down) resetPound()
            } else {
                consume = handlePound(down, repeat)
            }
        }
        if (!starDown && !poundDown) comboActive = false
        return consume
    }

    /** Swallows # while Home is shown and reports a short or long press to it. */
    private fun handlePound(down: Boolean, repeat: Boolean): Boolean {
        val handler = homeKeyHandler
        if (down) {
            if (!repeat) {
                if (handler == null) {
                    poundConsumed = false
                    return false
                }
                poundConsumed = true
                poundLongFired = false
                mainHandler.postDelayed(poundLongTask, ViewConfiguration.getLongPressTimeout().toLong())
            }
            return poundConsumed
        }
        mainHandler.removeCallbacks(poundLongTask)
        val wasConsumed = poundConsumed
        val longFired = poundLongFired
        resetPound()
        if (wasConsumed && !longFired) handler?.invoke(HomeKey.POUND_SHORT, KeyEvent.KEYCODE_POUND)
        return wasConsumed
    }

    private fun resetPound() {
        mainHandler.removeCallbacks(poundLongTask)
        poundConsumed = false
        poundLongFired = false
    }

    private fun takeScreenshot() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    companion object {
        /** Uptime of the last * + # combo, so Home can ignore the long-press of the key pressed first. */
        @Volatile
        var lastComboAt = 0L

        /** Set by MainActivity while Home is on screen; null otherwise. Called on the main thread. */
        @Volatile
        var homeKeyHandler: ((HomeKey, Int) -> Unit)? = null

        /** Non-null while the user has the service enabled. */
        @Volatile
        var instance: ScreenshotAccessibilityService? = null
            private set
    }
}
