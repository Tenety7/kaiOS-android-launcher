package com.flipos.launcher

import android.app.admin.DeviceAdminReceiver

/** Device-admin receiver required for the optional long-press * screen-lock shortcut. */
class LauncherDeviceAdminReceiver : DeviceAdminReceiver()
