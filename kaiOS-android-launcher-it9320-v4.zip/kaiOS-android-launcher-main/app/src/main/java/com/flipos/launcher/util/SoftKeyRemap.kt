package com.flipos.launcher.util

import android.view.KeyEvent

/**
 * The Airtel Smarta (it9320) has no real SOFT_LEFT / SOFT_RIGHT keys: its two
 * physical soft keys report MENU (left) and BACK (right). Every screen of the
 * launcher is written around SOFT_LEFT / SOFT_RIGHT, so activities route their
 * key events through here to translate the physical keys first.
 *
 * If the screen has no action for the translated key (e.g. no right-key action),
 * the original event is delivered as well, so BACK still goes back.
 */
inline fun remapPhoneSoftKeys(event: KeyEvent, dispatch: (KeyEvent) -> Boolean): Boolean {
    val mapped = when (event.keyCode) {
        KeyEvent.KEYCODE_MENU -> KeyEvent.KEYCODE_SOFT_LEFT
        KeyEvent.KEYCODE_BACK -> KeyEvent.KEYCODE_SOFT_RIGHT
        else -> return dispatch(event)
    }
    val remapped = KeyEvent(
        event.downTime, event.eventTime, event.action, mapped, event.repeatCount,
        event.metaState, event.deviceId, event.scanCode, event.flags, event.source,
    )
    return dispatch(remapped) || dispatch(event)
}
