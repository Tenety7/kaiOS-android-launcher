package com.flipos.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.Settings
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.doOnLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.flipos.launcher.data.AppRepository
import com.flipos.launcher.data.LauncherPrefs
import com.flipos.launcher.data.NotificationCounts
import com.flipos.launcher.ui.HomeRailAdapter
import com.flipos.launcher.service.ScreenshotAccessibilityService
import com.flipos.launcher.ui.RailItem
import com.flipos.launcher.util.launchAppByKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The KaiOS-style home screen:
 *  - a vertical rail of shortcut icons on the left (keys 1-9, top to bottom),
 *  - a large clock + date on the right, and
 *  - "Notifications · apps · Contacts" soft keys along the bottom.
 *
 * Tap an icon (or press its number key, or D-pad to it and press OK) to launch.
 * The center dots open All Apps; long-pressing them opens launcher Options.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: LauncherPrefs
    private lateinit var rail: RecyclerView
    private lateinit var appMenuButton: ImageView
    private lateinit var adapter: HomeRailAdapter
    private lateinit var clock: TextView
    private lateinit var ampm: TextView
    private lateinit var weekday: TextView
    private lateinit var dateLine: TextView
    private lateinit var notifCallsGroup: View
    private lateinit var notifCallsCount: TextView
    private lateinit var notifMessagesGroup: View
    private lateinit var notifMessagesCount: TextView
    private lateinit var notifOtherGroup: View
    private lateinit var notifOtherCount: TextView

    private val ampmFmt = SimpleDateFormat("a", Locale.getDefault())
    private val time12 = SimpleDateFormat("h:mm", Locale.getDefault())
    private val time24 = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val weekdayFmt = SimpleDateFormat("EEEE", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("MMM d", Locale.getDefault())

    /** Rail index awaiting an app from the picker (-1 = none). */
    private var pendingIndex = -1

    /** Set once a Back long-press has fired, so the matching key-up doesn't also open the drawer. */
    private var backLongPressHandled = false
    private val handledLongPressKeys = mutableSetOf<Int>()
    private var torchEnabled = false

    /** * and # held together = screenshot. Tracked here only to suppress the single-key actions
     *  (dialer / long-press) and to prompt for the accessibility service when it is off. */
    private var starDown = false
    private var poundDown = false
    private var comboActive = false

    /** The accent color applied this onCreate, so [onResume] can detect a change and [recreate]. */
    private var appliedAccentColor: LauncherPrefs.AccentColor? = null

    private val pickLauncher = registerForActivityResult(StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && pendingIndex >= 0) {
            result.data?.getStringExtra(AppPickerActivity.EXTRA_APP_KEY)?.let { key ->
                prefs.setShortcutAt(pendingIndex, key)
            }
        }
        pendingIndex = -1
        refreshShortcuts()
    }

    private val timeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = updateClock()
    }

    private val notifListener: () -> Unit = {
        runOnUiThread {
            updateNotifSummary()
            adapter.notifyItemRangeChanged(0, adapter.itemCount)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = LauncherPrefs(this)
        val accent = prefs.getAccentColor()
        appliedAccentColor = accent
        if (accent.themeOverlayRes != 0) theme.applyStyle(accent.themeOverlayRes, true)
        setContentView(R.layout.activity_main)

        clock = findViewById(R.id.clock)
        ampm = findViewById(R.id.ampm)
        weekday = findViewById(R.id.weekday)
        dateLine = findViewById(R.id.date_line)
        notifCallsGroup = findViewById(R.id.notif_calls_group)
        notifCallsCount = findViewById(R.id.notif_calls_count)
        notifMessagesGroup = findViewById(R.id.notif_messages_group)
        notifMessagesCount = findViewById(R.id.notif_messages_count)
        notifOtherGroup = findViewById(R.id.notif_other_group)
        notifOtherCount = findViewById(R.id.notif_other_count)
        rail = findViewById(R.id.shortcuts_rail)

        adapter = HomeRailAdapter(
            onClick = { _, item -> onRailClick(item) },
            onLongClick = { position, item -> onRailLongClick(position, item) },
            hasNotification = { app ->
                prefs.isIconNotificationDotEnabled() && NotificationCounts.packagesWithNotifications.contains(app.packageName)
            },
        )
        rail.layoutManager = LinearLayoutManager(this)
        rail.adapter = adapter
        rail.itemAnimator = null
        // Slot height is computed from the rail's actual height so 5 shortcuts are
        // always visible without scrolling, regardless of screen size/aspect ratio.
        rail.doOnLayout {
            val available = it.height - it.paddingTop - it.paddingBottom
            adapter.setItemHeightPx(available / HomeRailAdapter.SLOTS_VISIBLE)
        }

        findViewById<TextView>(R.id.softkey_left).setOnClickListener { openLeftKeyApp() }
        findViewById<TextView>(R.id.softkey_right).setOnClickListener { openRightKeyApp() }
        appMenuButton = findViewById<ImageView>(R.id.softkey_center).apply {
            setOnClickListener { openAppDrawer() }
            setOnLongClickListener { openOptions(); true }
            // Left jumps straight to the first pinned shortcut. The soft keys
            // either side of this button aren't keyboard-focusable, so without
            // this, default focus search would still wander into the rail on
            // its own (it's the only other focusable view) - landing on
            // whichever item geometric search happens to pick, not the top one.
            // Right has no focusable target and is swallowed so it's a no-op
            // instead of also leaking into the rail.
            setOnKeyListener { _, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        rail.layoutManager?.findViewByPosition(0)?.requestFocus() ?: rail.requestFocus()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> true
                    else -> false
                }
            }
        }

        // Back opens the app drawer; long-pressing it launches the configured app instead
        // (see onKeyDown/onKeyUp, which suppress this callback when a long-press fires).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = openAppDrawer()
        })

        updateClock()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(
            timeReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_TIME_TICK)
                addAction(Intent.ACTION_TIME_CHANGED)
                addAction(Intent.ACTION_TIMEZONE_CHANGED)
            },
        )
        starDown = false
        poundDown = false
        comboActive = false
        updateClock()
        refreshShortcuts()
        refreshLeftKeyLabel()
        refreshRightKeyLabel()
        focusAppMenu()
        NotificationCounts.addListener(notifListener)
        updateNotifSummary()
        maybePromptDefaultLauncher()
        // The accent color may have changed in Settings while Home was backgrounded;
        // theme overlays only apply at onCreate, so recreate to pick it up. Done last
        // (after registering the receiver/listener above) so onPause's matching
        // unregister calls below still have something to unregister.
        if (prefs.getAccentColor() != appliedAccentColor) recreate()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(timeReceiver)
        NotificationCounts.removeListener(notifListener)
    }

    // ----------------------------------------------------------- Data / clock

    private fun updateClock() {
        val now = Date()
        if (android.text.format.DateFormat.is24HourFormat(this)) {
            ampm.visibility = TextView.GONE
            clock.text = time24.format(now)
        } else {
            ampm.visibility = TextView.VISIBLE
            ampm.text = ampmFmt.format(now)
            clock.text = time12.format(now)
        }
        weekday.text = weekdayFmt.format(now)
        dateLine.text = dateFmt.format(now)
    }

    private fun refreshShortcuts() {
        Thread {
            // Resolve each shortcut (any activity component), dropping ones whose
            // app was uninstalled so the rail stays gap-free.
            val keys = prefs.getShortcuts()
            val resolved = keys.mapNotNull { key ->
                AppRepository.resolveComponent(this, key)?.let { key to it }
            }
            if (resolved.size != keys.size) prefs.setShortcuts(resolved.map { it.first })

            val entries = resolved.mapTo(ArrayList()) { RailItem(it.second) }
            if (resolved.size < LauncherPrefs.MAX_SHORTCUTS) entries.add(RailItem(null))

            if (isDestroyed) return@Thread
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                adapter.submit(entries)
            }
        }.start()
    }

    // --------------------------------------------------------------- Actions

    private fun onRailClick(item: RailItem) {
        val app = item.app
        if (app != null) launchAppByKey(app.key) else pickForIndex(prefs.getShortcuts().size)
    }

    private fun onRailLongClick(position: Int, item: RailItem) {
        if (item.app == null) {
            pickForIndex(prefs.getShortcuts().size)
            return
        }
        AlertDialog.Builder(this)
            .setTitle(item.app.label)
            .setItems(arrayOf("Change app", "Remove from Home")) { _, which ->
                when (which) {
                    0 -> pickForIndex(position)
                    1 -> {
                        prefs.removeShortcutAt(position)
                        refreshShortcuts()
                    }
                }
            }
            .show()
    }

    /** Open the phone dialer, prefilled with the pressed digit (or * / #). */
    private fun startDial(digit: String) {
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", digit, null)))
        } catch (e: Exception) {
            Toast.makeText(this, "No dialer available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickForIndex(index: Int) {
        pendingIndex = index
        pickLauncher.launch(Intent(this, AppPickerActivity::class.java))
    }

    private fun openAppDrawer() = startActivity(Intent(this, AppDrawerActivity::class.java))

    /** Highlight the "open app menu" button by default whenever Home is shown. */
    private fun focusAppMenu() = appMenuButton.post { appMenuButton.requestFocus() }

    private fun openLeftKeyApp() {
        val key = prefs.getLeftKeyApp()
        if (key != null) launchAppByKey(key) else openNotifications()
    }

    private fun openOptions() = startActivity(Intent(this, OptionsActivity::class.java))

    private fun openRightKeyApp() {
        val key = prefs.getRightKeyApp()
        if (key != null) {
            launchAppByKey(key)
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_DIAL))
            } catch (ignored: Exception) {
                Toast.makeText(this, "No contacts app", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateNotifSummary() {
        bindNotifBadge(notifCallsGroup, notifCallsCount, prefs.isCallBadgeEnabled(), NotificationCounts.calls)
        bindNotifBadge(notifMessagesGroup, notifMessagesCount, prefs.isMessageBadgeEnabled(), NotificationCounts.messages)
        bindNotifBadge(notifOtherGroup, notifOtherCount, prefs.isOtherBadgeEnabled(), NotificationCounts.other)
    }

    private fun bindNotifBadge(group: View, countView: TextView, enabled: Boolean, count: Int) {
        if (enabled && count > 0) {
            countView.text = if (count > 99) "99+" else count.toString()
            group.visibility = View.VISIBLE
        } else {
            group.visibility = View.GONE
        }
    }

    private fun refreshRightKeyLabel() {
        val key = prefs.getRightKeyApp()
        val label = key?.let { AppRepository.resolveComponent(this, it)?.label }
            ?: getString(R.string.softkey_contacts)
        findViewById<TextView>(R.id.softkey_right).text = label
    }

    private fun refreshLeftKeyLabel() {
        val key = prefs.getLeftKeyApp()
        val label = key?.let { AppRepository.resolveComponent(this, it)?.label }
            ?: getString(R.string.softkey_notifications)
        findViewById<TextView>(R.id.softkey_left).text = label
    }

    private fun openDialer() {
        try {
            startActivity(Intent(Intent.ACTION_DIAL))
        } catch (e: Exception) {
            Toast.makeText(this, "No dialer available", Toast.LENGTH_SHORT).show()
        }
    }

    /** The KaiOS "Notices" action: our own list screen, not the system shade. */
    private fun openNotifications() = startActivity(Intent(this, NoticesActivity::class.java))

    // ----------------------------------------------------------- Key handling

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        // * + # together: screenshot. When the accessibility service is on it takes the
        // screenshot itself (and swallows these keys before we see the second one), so
        // this branch only runs when the service is off.
        if ((keyCode == KeyEvent.KEYCODE_STAR || keyCode == KeyEvent.KEYCODE_POUND) &&
            ScreenshotAccessibilityService.instance == null
        ) {
            if (event.repeatCount == 0) {
                if (keyCode == KeyEvent.KEYCODE_STAR) starDown = true else poundDown = true
            }
            if (starDown && poundDown && !comboActive) {
                comboActive = true
                handledLongPressKeys.add(KeyEvent.KEYCODE_STAR)
                handledLongPressKeys.add(KeyEvent.KEYCODE_POUND)
                promptEnableScreenshotService()
            }
            if (comboActive) return true
        }

        // The Itel/Airtel It9320 reports the physical soft keys as BACK and MENU.
        // On Home only, BACK is the physical left key and MENU is the physical right key.
        // The launcher labels are opposite on this firmware, so map BACK -> right option
        // and MENU -> left option. Other activities keep their own normal behavior.
        when (keyCode) {
            KeyEvent.KEYCODE_SOFT_LEFT -> { openLeftKeyApp(); return true }
            KeyEvent.KEYCODE_SOFT_RIGHT -> { openRightKeyApp(); return true }
            KeyEvent.KEYCODE_BACK -> {
                if (event.isLongPress) {
                    backLongPressHandled = true
                    launchBackLongPressApp()
                    return true
                }
            }
            KeyEvent.KEYCODE_MENU -> {
                if (event.isLongPress) return true
                openLeftKeyApp()
                return true
            }
        }

        // Device-specific long-press shortcuts. The OS/firmware may intercept these
        // keys before an ordinary launcher app receives them; these handlers work only
        // when Android delivers the key events to MainActivity.
        if (event.isLongPress && keyCode in setOf(KeyEvent.KEYCODE_0, KeyEvent.KEYCODE_STAR, KeyEvent.KEYCODE_POUND)) {
            if (handledLongPressKeys.add(keyCode)) {
                when (keyCode) {
                    KeyEvent.KEYCODE_0 -> toggleTorch()
                    KeyEvent.KEYCODE_STAR -> lockScreen()
                    KeyEvent.KEYCODE_POUND -> toggleVibrateMode()
                }
            }
            return true
        }

        when (keyCode) {
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9,
            KeyEvent.KEYCODE_STAR,
            KeyEvent.KEYCODE_POUND -> return true
            KeyEvent.KEYCODE_CALL -> { openDialer(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_STAR) starDown = false
        if (keyCode == KeyEvent.KEYCODE_POUND) poundDown = false
        if (!starDown && !poundDown) comboActive = false
        if (handledLongPressKeys.remove(keyCode)) return true
        when (keyCode) {
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                startDial(('0' + (keyCode - KeyEvent.KEYCODE_0)).toString())
                return true
            }
            KeyEvent.KEYCODE_STAR -> { startDial("*"); return true }
            KeyEvent.KEYCODE_POUND -> { startDial("#"); return true }
        }
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (backLongPressHandled) {
                backLongPressHandled = false
                return true
            }
            openRightKeyApp()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun toggleTorch() {
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.CAMERA), 902)
            Toast.makeText(this, "Allow camera access, then long-press 0 again", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val manager = getSystemService(CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId == null) {
                Toast.makeText(this, "No flashlight available", Toast.LENGTH_SHORT).show()
                return
            }
            torchEnabled = !torchEnabled
            manager.setTorchMode(cameraId, torchEnabled)
        } catch (ignored: Exception) {
            Toast.makeText(this, "Flashlight is controlled by the phone firmware", Toast.LENGTH_LONG).show()
        }
    }

    private fun lockScreen() {
        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(this, LauncherDeviceAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) {
            dpm.lockNow()
        } else {
            try {
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                    putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Allow the launcher to lock the screen when * is held.")
                }
                startActivity(intent)
            } catch (ignored: Exception) {
                Toast.makeText(this, "This firmware does not allow screen locking from the launcher", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun promptEnableScreenshotService() {
        Toast.makeText(this, R.string.screenshot_enable_hint, Toast.LENGTH_LONG).show()
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (ignored: Exception) {
            // No accessibility settings screen on this firmware; the toast is all we can do.
        }
    }

    /** Long-press #: normal -> vibrate, and vibrate/silent -> normal. */
    private fun toggleVibrateMode() {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !notificationPolicyAccessGranted()) {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                Toast.makeText(this, "Allow Do Not Disturb access, then long-press # again", Toast.LENGTH_LONG).show()
            } catch (ignored: Exception) {
                Toast.makeText(this, "Vibrate mode is controlled by the phone firmware", Toast.LENGTH_LONG).show()
            }
            return
        }
        val ringerPrefs = getSharedPreferences("ringer_state", MODE_PRIVATE)
        try {
            if (audio.ringerMode == AudioManager.RINGER_MODE_NORMAL) {
                // Remember the ring volume: Android sets it to 0 in vibrate mode, and
                // going back to NORMAL with a 0 volume just lands in vibrate again.
                val volume = audio.getStreamVolume(AudioManager.STREAM_RING)
                if (volume > 0) ringerPrefs.edit().putInt("ring_volume", volume).apply()
                audio.ringerMode = AudioManager.RINGER_MODE_VIBRATE
            } else {
                audio.ringerMode = AudioManager.RINGER_MODE_NORMAL
                if (audio.getStreamVolume(AudioManager.STREAM_RING) == 0) {
                    val max = audio.getStreamMaxVolume(AudioManager.STREAM_RING)
                    val saved = ringerPrefs.getInt("ring_volume", (max / 2).coerceAtLeast(1))
                    audio.setStreamVolume(AudioManager.STREAM_RING, saved.coerceIn(1, max), 0)
                    // Setting the volume can flip the mode again on some firmwares.
                    audio.ringerMode = AudioManager.RINGER_MODE_NORMAL
                }
            }
            val vibrate = audio.ringerMode == AudioManager.RINGER_MODE_VIBRATE
            Toast.makeText(this, if (vibrate) "Vibrate mode" else "Sound mode", Toast.LENGTH_SHORT).show()
        } catch (ignored: Exception) {
            Toast.makeText(this, "This firmware does not allow changing ring mode", Toast.LENGTH_LONG).show()
        }
    }

    private fun notificationPolicyAccessGranted(): Boolean {
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        return notificationManager.isNotificationPolicyAccessGranted
    }

    private fun launchBackLongPressApp() {
        val key = prefs.getBackLongPressApp()
        if (key == null) {
            Toast.makeText(this, R.string.back_longpress_unset_toast, Toast.LENGTH_SHORT).show()
        } else {
            launchAppByKey(key)
        }
    }

    // ------------------------------------------------------ Default launcher

    private fun isDefaultLauncher(): Boolean {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolved = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolved?.activityInfo?.packageName == packageName
    }

    private fun maybePromptDefaultLauncher() {
        // Gently hint, but never yank the user away — they opt in deliberately via
        // Options → "Set as Default Launcher".
        if (defaultPromptShown || isDefaultLauncher()) return
        defaultPromptShown = true
        Toast.makeText(this, R.string.choose_home_app, Toast.LENGTH_LONG).show()
    }

    companion object {
        // Shown at most once per process so we don't nag on every resume.
        private var defaultPromptShown = false
    }
}
