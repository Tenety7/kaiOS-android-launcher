package com.flipos.launcher.service

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Takes a screenshot when * and # are pressed together, on any screen.
 *
 * Android gives launchers no way to take a screenshot, so this tiny accessibility
 * service (enabled once by the user in Settings > Accessibility) does it with
 * GLOBAL_ACTION_TAKE_SCREENSHOT (Android 9+). It also sees key events before the
 * foreground app, so while the combo is held it swallows * and # – otherwise the
 * home screen would also open the dialer or fire its long-press actions.
 */
class ScreenshotAccessibilityService : AccessibilityService() {

    private var starDown = false
    private var poundDown = false
    private var comboActive = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_STAR && code != KeyEvent.KEYCODE_POUND) return false
        val down = event.action == KeyEvent.ACTION_DOWN
        if (code == KeyEvent.KEYCODE_STAR) starDown = down else poundDown = down

        if (down && starDown && poundDown && !comboActive) {
            comboActive = true
            takeScreenshot()
        }
        val consume = comboActive
        if (!starDown && !poundDown) comboActive = false
        return consume
    }

    private fun takeScreenshot() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    companion object {
        /** Non-null while the user has the service enabled. */
        @Volatile
        var instance: ScreenshotAccessibilityService? = null
            private set
    }
}
